import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ShowData4 {
	

	
	/* JDBC driver for SQLite */
	public static final String DB_JDBC = "org.sqlite.JDBC";
	
	/* URL to the data base in SQLite using JDBC */
	public static final String DB_URL = "jdbc:sqlite:c2pl4.db";


public static void main(String[] args) {
		
		/* The connection object to the database */
		Connection connection = null;
		
		/* The data item */
		String item;
		
		/* The value of the item */
		int value = 0;
		
		/* Try to connect to the database */
		try {
			
			/* Connect to the database using JDBC */
			Class.forName(DB_JDBC);
			connection = DriverManager.getConnection(DB_URL);
			
			/* Generate the statement */
			Statement statement = connection.createStatement();
			statement.setQueryTimeout(30);
			String query = "select * from items";
			
			/* Execute the statement */
			ResultSet result = statement.executeQuery(query);
			
			/* If there is a result then get the value */
			while(result.next()) {
				item = result.getString("item");
				value = result.getInt("value");
				System.out.println("[" + item + ": " + value + "]");
			}
			
			/* Close the result, the statement and the connection */
			result.close();
			statement.close();
			connection.close();
			
		}
		catch(ClassNotFoundException e) {
			System.err.println(" Class Not Found Exception: " + e.getMessage());
		}
		catch(SQLException e) {
			System.err.println(" SQL Exception: " + e.getMessage());
		}
		
	}
	
}