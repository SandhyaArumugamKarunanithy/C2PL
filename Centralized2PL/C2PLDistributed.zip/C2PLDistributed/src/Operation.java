

import java.io.Serializable;

public class Operation implements Serializable {
	
	
	public static final String TAG = Operation.class.getName();
	
	public static final int TYPE_READ = 1;
	public static final int TYPE_WRITE = 2;
	public static final int TYPE_MATH = 3;


	private static final long serialVersionUID = 1L;
	
	
	private int transactionId;
	
	
	private int type;
	

	private String item;
	

	private String operand1;

	private String operand2;
	
	private String operator;
	
	public Operation(int transactionId, int type) {
		this.transactionId = transactionId;
		this.type = type;
	}
	
	
	public Operation(int transactionId, int type, String item) {
		this.transactionId = transactionId;
		this.type = type;
		this.item = item;
	}
	
	public Operation(int transactionId, int type, String item, 
			String operand1, String operator, String operand2) {
		this.transactionId = transactionId;
		this.type = type;
		this.item = item;
		this.operand1 = operand1;
		this.operator = operator;
		this.operand2 = operand2;
	}

	
	public String getItem() {
		return item;
	}

	
	public Lock getLock() {
		

		int lockType;
		
		
		switch(type) {
		
	
			case TYPE_READ:
				lockType = Lock.TYPE_READ;
			break;
			
			
			case TYPE_WRITE:
				lockType = Lock.TYPE_WRITE;
			break;
			
		
			default:
				System.out.println(TAG + " This operation cannot obtain a lock!");
				return null;
		
		}
		
		
		Lock lock = new Lock(lockType, item, transactionId);
		return lock;
	}


	public String getOperand1() {
		return operand1;
	}

	public String getOperand2() {
		return operand2;
	}

	public String getOperator() {
		return operator;
	}

	
	public int getTransactionId() {
		return transactionId;
	}

	
	public int getType() {
		return type;
	}

	
	public void setItem(String item) {
		this.item = item;
	}


	public void setOperand1(String operand1) {
		this.operand1 = operand1;
	}


	public void setOperand2(String operand2) {
		this.operand2 = operand2;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	
	public void setType(int type) {
		this.type = type;
	}
	
	
	public String toString() {
		
				StringBuilder builder = new StringBuilder();
		
		switch(type) {
			
			case Operation.TYPE_READ:
				builder.append("[READ(" + item + "), ");
			break;
			
			case Operation.TYPE_WRITE:
				builder.append("[WRITE(" + item + "), ");
			break;
			
			case Operation.TYPE_MATH:
				builder.append("[MATH(" + item + "=" + operand1 + operator + operand2 + "), ");
			break;
			
		}
		
		builder.append("transaction " + transactionId + 
				", siteID " + Transaction.getSiteId(transactionId) + " ]");
		
	
		return builder.toString();
	}

}
