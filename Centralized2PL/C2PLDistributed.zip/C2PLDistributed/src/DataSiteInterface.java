

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface DataSiteInterface extends Remote {
	
	
	public void abort() throws RemoteException;

	public void unblock() throws RemoteException;
	
	
	public void write() throws RemoteException;

}
