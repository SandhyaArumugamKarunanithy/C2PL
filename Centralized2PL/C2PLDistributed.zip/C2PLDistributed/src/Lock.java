

public class Lock {
	
	
	public static final String TAG = Lock.class.getName();
	

	public static final int TYPE_READ = 1;
	public static final int TYPE_WRITE = 2;
	public static final int TYPE_READ_AND_WRITE = 3;
	
	
	private String item;
	
	
	private int type;
	
	
	private int transactionId;

	public Lock(int type, String item, int transactionId) {
		this.type = type;
		this.item = item;
		this.transactionId = transactionId;
	}

	
	public String getItem() {
		return item;
	}

	
	public int getTransactionId() {
		return transactionId;
	}

	
	 
	public int getType() {
		return type;
	}

	public void setItem(String item) {
		this.item = item;
	}


	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public void setType(int type) {
		this.type = type;
	}
	
	
	public String toString() {
		

		StringBuilder builder = new StringBuilder();
		builder.append("[");
		builder.append(item + ", ");
		
		switch(type) {
		
			case Lock.TYPE_READ:
				builder.append("read");
			break;
			
			case Lock.TYPE_WRITE:
				builder.append("write");
			break;
			
			case Lock.TYPE_READ_AND_WRITE:
				builder.append("read/write");
			break;
			
		}
		

		builder.append(", transaction " + transactionId + 
				", siteId " + Transaction.getSiteId(transactionId) + " ]");
		
		
		return builder.toString();
	}
	

	public void upgradeType(int newType) {
		if(type == Lock.TYPE_READ && newType == Lock.TYPE_WRITE) {
			type = Lock.TYPE_READ_AND_WRITE;
		}
		else if(type == Lock.TYPE_WRITE && newType == Lock.TYPE_READ) {
			type = Lock.TYPE_READ_AND_WRITE;
		}
	}

}
