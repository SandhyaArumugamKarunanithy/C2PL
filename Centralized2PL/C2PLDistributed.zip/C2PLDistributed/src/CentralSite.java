

import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class CentralSite implements CentralSiteInterface {

	public static final String TAG = CentralSite.class.getName();
	
	private static boolean verbose;
	
	
	public static String getTimestamp()
	{
		
		return "[" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").format(new Date()) + "]";
	}
	
	public static boolean isVerbose() {
		return verbose;
	}
	

	public static void main (String[] args) {
		

		try {
			
		
			verbose = (args.length > 2) ? Boolean.parseBoolean(args[2]) : true;
			

			int port = Integer.parseInt(args[0]);
			
			
			long checkDelay = Long.parseLong(args[1]);
			 
		
			new CentralSite(port, checkDelay);
			println(TAG, "Central Site started at port " + port);
		
		}
		catch(NumberFormatException e) {
			System.out.println(TAG + " Number Format Exception: " + e.getMessage());
		}
		catch(NullPointerException e) {
			System.out.println(TAG + " Null Pointer Exception: " + e.getMessage());
		}
		catch (Exception e) {
			System.out.println(TAG + " Exception in main: " + e.getMessage());
		}
	}
	
	
	public static void print(String tag, String message) {
		
		
		if(verbose) {
			System.out.println(CentralSite.getTimestamp() + " " + tag + ": " + message);
		}
	}
	

	public static void println(String tag, String message) {
		

		if(verbose) {
			System.out.println("");
			System.out.println(CentralSite.getTimestamp() + " " + tag + ": " + message);
		}
	}
	

	public static void printRegistry(int port) {
		
		try {
			Registry registry = LocateRegistry.getRegistry(port);
			String[] list = registry.list();
			int n = list.length;
			StringBuilder builder = new StringBuilder();
			builder.append("RMI Registry: <");
			for(int i = 0; i < n; i += 1) {
				if(i == 0) {
					builder.append(list[i]);
				}
				else {
					builder.append(", " + list[i]);
				}
			}
			builder.append(">");
			print(TAG, builder.toString());
		}
		catch(RemoteException e) {
			System.out.println(TAG + " Remote Exception: " + e.getMessage());
		}
		
	}
	
	public static void setVerbose(boolean verbose) {
		CentralSite.verbose = verbose;
	}

	private LockHandler lockHandler;
	

	private int siteCount = 0;
	

	private int port;
	
	
	private long checkDelay;

	private int deadlockCount;
	

	public CentralSite(int port, long checkDelay) {
		
	
		this.port = port;

		this.checkDelay = checkDelay;
		
		
		deadlockCount = 0;
		
		
		lockHandler = new LockHandler();
		

		try {
			
		
			Registry registry = LocateRegistry.createRegistry(port);
			
			
			CentralSiteInterface stub = (CentralSiteInterface) UnicastRemoteObject.exportObject(this, 0);
			registry.bind("c2pl", stub);
			 
			Timer timer = new Timer();
			print(TAG, "Timer created for checking deadlocks");
			
			/**/
			timer.schedule(new TimerTask() {
				
				@Override
	            public void run() {
					CentralSite.printRegistry(port);
					checkDeadlocks();
					print(TAG, "Deadlock checked\n");
				}
				
			}, checkDelay, checkDelay);
			print(TAG, "Deadlock is checked every " + checkDelay + " miliseconds");
			
		}
		catch(RemoteException e) {
			System.out.println(TAG + " Remote Exception: " + e.getMessage());
		}
		catch(AlreadyBoundException e) {
			System.out.println(TAG + " Already Bound Exception: " + e.getMessage());
		}
		catch(Exception e) {
			System.out.println(TAG + " Exception: " + e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * 
	 */
	public synchronized void checkDeadlocks() {
		
		print(TAG, "Checking Deadlocks...");
		
		/* Get the deadlock information */
		Pair<Integer, ArrayList<Integer>> result = lockHandler.checkDeadlocks();
		
		/* If there is result means there is a deadlock */
		if(result != null) {
			
			/* A deadlock was found, increment the counter by one */
			deadlockCount += 1;
			
			print(TAG, "Deadlock info obtained");
			
			/* Get the transaction to be aborted and its site */
			int transactionToAbort = result.getFirst().intValue();
			int siteId = Transaction.getSiteId(transactionToAbort);
			print(TAG, "Transaction to be aborted: " + transactionToAbort + " from site " + siteId);
			
			/* Try to abort the transaction */
			try {
				
				/* Get the stub to the data site */
				DataSiteInterface dataSiteStub = getDataSiteStub(siteId);
				
				if(dataSiteStub == null) {
					
					print(TAG, "Data site stub for site " + siteId + " is null");
					
				}
				else {
					
					/* Abort */
					dataSiteStub.abort();
					print(TAG, "Data site " + siteId + " aborted the transaction");
					
				}
				
			}
			catch(Exception e) {
				System.out.println(TAG + " Exception in checkDeadlocks: " + e.getMessage());
			}
			
			/* Get the list of unblocked sites */
			ArrayList<Integer> unblocked = result.getSecond();
			print(TAG, unblocked.size() + " sites will be unlocked");
			
			/* Traverse the unblocked sites list */
			for(Integer site: unblocked) {
				
				/* Try to unblock the site */
				try {
					
					/* Get the stub for the unblocked data site */
					DataSiteInterface dataSiteStub = getDataSiteStub(site);
					print(TAG, "Stub for data site " + site + " obtained");
					
					if(dataSiteStub != null) {
						print(TAG, "Stub says is not null");
						
						/* Unblock the site */
						dataSiteStub.unblock();
						print(TAG, "Data Site " + site + " unblocked!");
						
					}
					else {
						
						print(TAG, "Data site stub is null");
						
					}
					
				}
				catch(Exception e) {
					System.out.println(TAG + " Exception in checkDeadlocks: " + e.getMessage());
					e.printStackTrace();
				}
			}
		}
		else {
			print(TAG, "Deadlock list is null = No deadlocks found");
		}
		
		/* Print the number of deadlocks so far */
		print(TAG, "Deadlocks detected so far: " + deadlockCount);
	}


	public long getCheckDelay() {
		return checkDelay;
	}

	private DataSiteInterface getDataSiteStub(int id) {
		
		println(TAG, "getDataSiteStub");
		print(TAG, "Get stub for data site " + id);
		
		/* Try to get the required data site stub */
		try {
			
			/* Access to the RMI registry */
			Registry registry = LocateRegistry.getRegistry(port);
			//print(TAG, "Obtained acces to the registry");
			
			/* Get the data site stub */
			String siteStubName = "c2pl" + id;
			DataSiteInterface dataSiteStub = (DataSiteInterface) registry.lookup(siteStubName);
			
			/* Return the data site stub */
			//print(TAG, "Data Site Stub for site " + id + " obtained");
			return dataSiteStub;
			
		}
		catch(RemoteException e) {
			System.out.println(TAG + " Remote Exception: " + e.getMessage());
		}
		catch(NotBoundException e) {
			System.out.println(TAG + " Not Bound Exception: " + e.getMessage());
		}
		catch(NullPointerException e) {
			System.out.println(TAG + " Null Pointer Exception: " + e.getMessage());
		}
		catch(Exception e) {
			System.out.println(TAG + " Exception in getDataSiteStub: " + e.getMessage());
			e.printStackTrace();
		}
		
		print(TAG, "Data Site Stub for site " + id + " is null");
		return null;
		
	}


	public int getDeadlockCount() {
		return this.deadlockCount;
	}

	
	public LockHandler getLockHandler() {
		print(TAG, "Lock Handler requested");
		return lockHandler;
	}

	public int getPort() {
		print(TAG, "port requested");
		return port;
	}


	public int getSiteCount() {
		print(TAG, "Site count requested");
		return siteCount;
	}

	
	public synchronized int nextSiteId() throws RemoteException {
		
		/**/
		siteCount += 1;
		print(TAG, "Next site id requested: " + siteCount);
		
		/**/
		return siteCount;
	}
	
	
	public synchronized void releaseLock(Transaction transaction) throws RemoteException {
		
		println(TAG, "Transaction " + transaction.getId() + " requests to release its locks");
		
		/* Try to release the locks from the transaction */
		try {
			
			/* Get the list of unlocked sites */
			List<Integer> unblockedSites = lockHandler.releaseLocks(transaction);
			print(TAG, "Number of unlocked sites by transaction " + transaction.getId() + " = " + unblockedSites.size());
			
			/* For every unblocked site in the list */
			int n = unblockedSites.size();
			for(int i = 0; i < n; i += 1) {
				
				/* Get the site id */
				int siteId = unblockedSites.get(i).intValue();
				print(TAG, "Unblocking site " + siteId);
				
				/* Obtain the stub to the site */
				print(TAG, "Requesting Data Site object for site " + siteId);
				DataSiteInterface dataSiteStub = getDataSiteStub(siteId);
				print(TAG, "Object obtained for data site " + siteId);
				
				if(dataSiteStub == null) {
					print(TAG, "Object to data site " + siteId + " is null <WRONG>");
				}
				
				/* Unblock the data site */
				print(TAG, "Resuming data site " + siteId);
				dataSiteStub.write();
				//print(TAG, "Information for site " + siteId + " was printed");
				dataSiteStub.unblock();
				print(TAG, "Data site " + siteId + " resumed");
				
			}
			
			/* Print the lock manager state */
			lockHandler.print();
			
		}
		catch(NullPointerException e) {
			System.out.println(TAG + " Null Pointer Exception in releaseLock: " + e.getMessage());
		}
		catch(Exception e) {
			System.out.println(TAG + " Exception in releaseLock: " + e.getMessage());
		}
	}


	public synchronized boolean requestLock(Operation operation) throws RemoteException {
		
		println(TAG, "Operation from transaction " + operation.getTransactionId() + " is requesting a lock");
		
	
		try {
			
		
			boolean result = lockHandler.requestLock(operation);
			String g = result? "GRANTED":"NOT GRANTED";
			print(TAG, "Lock for Operation from transaction " + operation.getTransactionId() + " : " + g);
			
			
			lockHandler.print();
			
		
			return result;
			
		}
		catch(NullPointerException e) {
			System.out.println(TAG + " Null Pointer Exception in requestLock: " + e.getMessage());
		}
		catch(Exception e) {
			System.out.println(TAG + " Exception in requestLock: " + e.getMessage());
		}
		
		
		return false;
	}

	
	public void setCheckDelay(long checkDelay) {
		this.checkDelay = checkDelay;
	}
	
	
	public void setLockHandler(LockHandler lockHandler) {
		this.lockHandler = lockHandler;
	}
	
	
	public void setPort(int port) {
		this.port = port;
	}


	public void setSiteCount(int siteCount) {
		this.siteCount = siteCount;
	}

}
