

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class FileUtil {
	
	
	public static final String TAG = FileUtil.class.getName();
	

	public ArrayList<Transaction> history;

	
	private int siteId;


	private int transactionIdCount = 1;

	private int transactionIdOffset = 10000;


	public FileUtil(int siteId) {
		this.siteId = siteId;
		history = new ArrayList<Transaction>();
	}

	
	public ArrayList<Transaction> generateTransactions(ArrayList<String> commands) throws Exception {
		
	
		int n = commands.size();
		
		
		if(n <= 0) {
			return null;
		}
	
		ArrayList<Transaction> transactions = new ArrayList<Transaction>();

		Transaction transaction = null;
		
		for(int i = 0; i < n; i += 1) {
			
			
			String command = commands.get(i);
			
		
			if(command.toLowerCase().contains("transaction")) {
				
				
				if(transaction != null) {
					transactions.add(transaction);
				}
				
			
				transaction = new Transaction(getNewTransactionId());
			}
			else {
				
			
				char commandType = command.trim().charAt(0);
				
				
				switch(commandType) {
				
			
					case 'l': {
						
						
						Pattern pattern = Pattern.compile(".*\\((.*)\\).*");
						Matcher matcher = pattern.matcher(command);
						
						
						if(matcher.matches()) {
							
						
							String item = matcher.group(1);
							Operation operation = new Operation(
									transaction.getId(), Operation.TYPE_READ, item);
							
				
							transaction.addOperation(operation);
							
						}
						else {
							throw new Exception("Read operation " + command + " has wrong format");
						}
						
						break;
					}
					
					
					case 's': {
						
				
						Pattern pattern = Pattern.compile(".*\\((.*)\\).*");
						Matcher matcher = pattern.matcher(command);
						
					
						if(matcher.matches()) {
						
							String item = matcher.group(1);
							Operation operation = new Operation(
									transaction.getId(), Operation.TYPE_WRITE, item);
							
							
							transaction.addOperation(operation);
							
						}
						else {
							throw new Exception("Write operation " + command + " has wrong format");
						}
						
						break;
					}
					
		
					case 'a': {
						
					
						Pattern pattern = Pattern.compile("a(.*)\\=(.*)(\\+|\\-|\\*|\\/)(.*);");
						Matcher matcher = pattern.matcher(command);
						
						if(matcher.matches()) {
							
						
							String item = matcher.group(1);
							String operand1 = matcher.group(2);
							String operator = matcher.group(3);
							String operand2 = matcher.group(4);
							Operation operation = new Operation(transaction.getId(), 
									Operation.TYPE_MATH, item, operand1, operator, operand2);
							
				
							transaction.addOperation(operation);
							
						}
						else {
							
					
							pattern = Pattern.compile("a(.*)\\=(.*);");
							matcher = pattern.matcher(command);
							
							
							
							if(matcher.matches()) {
								
								String item = matcher.group(1);
								String operand1 = matcher.group(2);
								String operator = "+";
								String operand2 = "0";
								Operation operation = new Operation(transaction.getId(), 
										Operation.TYPE_MATH, item, operand1, operator, operand2);
								
	
								transaction.addOperation(operation);
								
							}
							else {
								throw new Exception("Math operation " + command + " has wrong format");
							}
							
						}
						
						break;
					}
								default:
						throw new Exception("Undefined operation " + command);
				
				}
			}
		}
	
		if(transaction != null) {
			transactions.add(transaction);
		}
		

		return transactions;
	}

	public ArrayList<Transaction> getHistory() {
		return history;
	}
	

	public int getSiteId() {
		return siteId;
	}
	

	private int getNewTransactionId() {
		
		int transactionId = siteId * transactionIdOffset + transactionIdCount;
	
		transactionIdCount += 1;
		
	
		return transactionId;
	}
	
	
	public int getTransactionIdCount() {
		return transactionIdCount;
	}
	
	
	public int getTransactionIdOffset() {
		return transactionIdOffset;
	}
	

	public void load(String filepath) throws Exception {
		
		ArrayList<String> fileData = readCommandsFile(filepath);
		ArrayList<Transaction> transactions = generateTransactions(fileData);
		setHistory(transactions);
		
	}
	
	
	public Transaction popTransaction() {
		
		if(history.size() > 0) {
			
			
			return history.remove(0);
		}
		
	
		return null;
	}
	

	public ArrayList<String> readCommandsFile(String filepath) {
		

		ArrayList<String> commands = new ArrayList<String>();
		
		
		try {
			
			
			BufferedReader reader = new BufferedReader(new FileReader(filepath));
			
		
			String line;
			while((line = reader.readLine()) != null && !line.trim().isEmpty()) {
				
				
				commands.add(line);
			}
			
			reader.close();
			
		}
		catch(IOException e) {
			System.out.println("IO Exception: " + e.getMessage());
		}
		

		return commands;
	}
	
	
	public void setHistory(ArrayList<Transaction> history) {
		this.history = history;
	}

	public void setTransactionIdCount(int transactionIdCount) {
		this.transactionIdCount = transactionIdCount;
	}
	
	
	public void setTransactionIdOffset(int transactionIdOffset) {
		this.transactionIdOffset = transactionIdOffset;
	}

}
