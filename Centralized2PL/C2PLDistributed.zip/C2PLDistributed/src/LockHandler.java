

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Set;


public class LockHandler {
	
	
	public static final String TAG = LockHandler.class.getName();

	private Hashtable<String, ArrayList<Lock>> lockTable;
	
	
	private Hashtable<String, ArrayList<Operation>> queueTable;

	public LockHandler() {
		lockTable = new Hashtable<String, ArrayList<Lock>>();
		queueTable = new Hashtable<String, ArrayList<Operation>>();
	}
	

	public ArrayList<Integer> abortTransaction(int transactionId) {
		
	
		Transaction transaction = new Transaction(transactionId);
	
		try {
			
	
			print();
			

			removeBlockedOperations(transaction);
			

			print();
			

			ArrayList<Integer> unblocked = releaseLocks(transaction);
			

			print();
			

			return unblocked;
		}
		catch(Exception e) {
			System.out.println(TAG + " Exception while aborting transaction " 
					+ transactionId + ": " + e.getMessage());
			
	
			return new ArrayList<Integer>();
		}
		
	}

	public Pair<Integer, ArrayList<Integer>> checkDeadlocks() {
		
	
		GraphHelper gh = new GraphHelper();
		
		
		for(String item : lockTable.keySet()) {
			
		
			ArrayList<Lock> locks = lockTable.get(item);
			
			 
			ArrayList<Operation> blockedOperations = queueTable.get(item);
			
	
			if(blockedOperations != null && blockedOperations.size() != 0) {
				
			
				int n = locks.size();
				
	
				for(int i = 0; i < n; i += 1) {
					
					
					Integer transaction1 = locks.get(i).getTransactionId();
				
					int m = blockedOperations.size();
					
				
					for(int j = 0; j < m; j += 1) {
						
			
						Integer transaction2 = blockedOperations.get(j).getTransactionId();
						
						if(!transaction1.equals(transaction2)) {
							gh.addDependency(transaction1, transaction2);
						}
					}
				}
			}
		}
		
	
		List<Integer> edgesToRemove = gh.checkCycles();
		
		if(edgesToRemove != null) {
			
		
			Integer abortingTransaction = edgesToRemove.get(1);
			
			
			System.out.println("***********Deadlock Found**********");
			System.out.println("Deadlock in " + edgesToRemove.get(0) + 
					" to " + edgesToRemove.get(1));
			System.out.println("Transaction to be aborted: " + abortingTransaction.intValue());
			
			
			ArrayList<Integer> unblocked = abortTransaction(abortingTransaction.intValue());
			
			
			return new Pair<Integer, ArrayList<Integer>>(abortingTransaction, unblocked);
		}
		else {
			return null;
		}
	}
	
	
	public Operation dequeueOperation(String item) {
		
		
		if(!queueTable.containsKey(item)) {
			return null;
		}

		ArrayList<Operation> operations = queueTable.get(item);
		
		
		int n = operations.size();
		
		
		if(n <= 0) {
			queueTable.remove(item);
			return null;
		}
		else {
			
		
			if(isLockCompatible(operations.get(0).getLock())) {
				
			
				Operation operation = operations.remove(0);
				
				
				if(operations.size() == 0) {
					queueTable.remove(item);
				}
				
		
				return operation;
				
			}
			else {
				return null;
			}
			
		}
		
	}
	

	public Lock findLock(int transactionId, String item) {
		
		
		ArrayList<Lock> locks = lockTable.get(item);
		
		
		if(locks == null) {
			return null;
		}
		
		
		int n = locks.size();
		
		
		for(int i = 0; i < n; i += 1) {
			
			
			Lock currentLock = locks.get(i);
			
		
			if(currentLock.getTransactionId() == transactionId) {
				return currentLock;
			}
		}
		
	
		return null;
		
	}
	
	
	public ArrayList<Lock> findLocks(int transactionId) {
		
		
		ArrayList<Lock> locks = new ArrayList<Lock>();
		
		
		Set<String> keys = lockTable.keySet();
		
		for(String key : keys) {
			

			ArrayList<Lock> lockedLocks = lockTable.get(key);
			
			
			int n = lockedLocks.size();
			
			
			for(int i = 0; i < n; i += 1) {
				
			
				if(lockedLocks.get(i).getTransactionId() == transactionId) {
					locks.add(lockedLocks.get(i));
				}
			}
			
		}
		

		return locks;
		
	}
	

	public Hashtable<String, ArrayList<Lock>> getLockTable() {
		return lockTable;
	}
	

	public Hashtable<String, ArrayList<Operation>> getQueueTable() {
		return queueTable;
	}
	

	public boolean insertLock(Lock lock) {
		
	
		String item = lock.getItem();
		
		
	
		if(!lockTable.containsKey(item)) {
			lockTable.put(item, new ArrayList<Lock>());
		}
		

		return lockTable.get(item).add(lock);
		
	}

	
	public boolean isLockCompatible(Lock lock) {
		
	
		String item = lock.getItem();
	
		ArrayList<Lock> locks = lockTable.get(item);
	
		if(locks == null) {
			return true;
		}
		

		switch(lock.getType()) {
		

			case Lock.TYPE_READ: {
				
				
				int n = locks.size();
				
		
				for(int i = 0; i < n; i += 1) {
					
					
					Lock currentLock = locks.get(i);
					
			
					if(currentLock.getTransactionId() != lock.getTransactionId() && 
							currentLock.getType() >= Lock.TYPE_WRITE) {
						return false;
					}
				}
				
				break;
			}
			

			case Lock.TYPE_WRITE: {
				
		
				int n = locks.size();
				
				
				for(int i = 0; i < n; i += 1) {
					
					Lock currentLock = locks.get(i);
					
					
					if(currentLock.getTransactionId() != lock.getTransactionId()) {
						return false;
					}
				}
				
				break;
				
			}
		
			default:
				System.out.println(TAG + " Lock is imcompatible");
				return false;
		
		}
		
		return true;
		
	}


	public void print() {

		printTimestamp();

		printLockTable();

		printQueueTable();
		
		System.out.println("\n");
		
	}

	
	public void printLockTable() {
		
	
		System.out.println("Lock Table");
		
		if(lockTable.isEmpty()) {
			System.out.println("[]");
			return;
		}
		

		for(String item : lockTable.keySet()) {
			
			
			ArrayList<Lock> locks = lockTable.get(item);
			

			int n = locks.size();
			
		
			for(int i = 0; i < n; i += 1) {
				
		
				System.out.println(locks.get(i).toString());
				
			}
			
			System.out.println();
			
		}
	}
	

	public void printQueueTable() {
		
	
		System.out.println("Queue Table");
		
		
		if(queueTable.isEmpty()) {
			System.out.println("[]");
			return;
		}
		
		
		for(String item : queueTable.keySet()) {
			
			
			ArrayList<Operation> operations = queueTable.get(item);
			
	
			int n = operations.size();

			for(int i = 0; i < n; i += 1) {
				
			
				System.out.println(operations.get(i).toString());
				
			}
			
			System.out.println();
			
		}
	}
	
	
	public void printTimestamp() {
		
		Date currentDate = new Date();
		String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").format(currentDate);
		

		System.out.println("Timestamp: " + timestamp);
		
	}

	
	public boolean queueOperation(String item, Operation operation) {
		
	
		if(!queueTable.containsKey(item)) {
			queueTable.put(item, new ArrayList<Operation>());
		}
		
	
		return queueTable.get(item).add(operation);
		
	}
	

	public ArrayList<Integer> releaseLocks(Transaction transaction) throws Exception {
		
	
		ArrayList<Integer> unlockedSites = new ArrayList<Integer>();
		
		
		ArrayList<Lock> locks = findLocks(transaction.getId());
		

		int n = locks.size();
		
	
		for(int i = 0; i < n; i += 1) {
			
		
			Lock currentLock = locks.get(i);
			
			removeLock(currentLock);
			
		
			Operation operation = dequeueOperation(currentLock.getItem());
			
			if(operation != null) {
				
				
				Lock nextLock = operation.getLock();
				
				if(isLockCompatible(nextLock)) {
					
		
					Lock oldLock = findLock(nextLock.getTransactionId(), nextLock.getItem());
				
					if(oldLock == null) {
				
						insertLock(nextLock);
					}
					else {
						
						
						oldLock.upgradeType(nextLock.getType());
					}
					
					
					int siteId = Transaction.getSiteId(operation.getTransactionId());
					
				
					unlockedSites.add(siteId);
				}
			}
		}
		
	
		printTimestamp();
		
		System.out.println("Transaction " + transaction.getId() + " releases all of its locks");
		
		return unlockedSites;
		
	}
	

	public void removeBlockedOperations(Transaction transaction) {
		

		int transactionId = transaction.getId();
		
		
		Set<String> keys = queueTable.keySet();
		
		
		for(String key : keys) {
			
			
			ArrayList<Integer> remove = new ArrayList<Integer>();
			ArrayList<Operation> operations = queueTable.get(key);
			int n = operations.size();
			
			for(int i = n - 1; i >= 0; i -= 1) {
				Operation operation = operations.get(i);
				if(operation.getTransactionId() == transactionId) {
					remove.add(i);
				}
			}
			
			for(int i : remove) {
				queueTable.get(key).remove(i);
			}
			
		}
		
	}
	
	
	public boolean removeLock(Lock lock) {
		
	
		String item = lock.getItem();
		
	
		ArrayList<Lock> locks = lockTable.get(item);
		
	
		int n = locks.size();
		
	
		for(int i = 0; i < n; i += 1) {
			
		
			Lock currentLock = locks.get(i);
			
			if(currentLock.getTransactionId() == lock.getTransactionId()) {
				
			
				lockTable.get(item).remove(currentLock);
				
			
				if(lockTable.get(item).size() == 0) {
					lockTable.remove(item);
				}
				
			
				return true;
				
			}
		}
		
	
		return false;
		
	}
	

	public boolean requestLock(Operation operation) throws Exception {
		
	
		Lock lock = operation.getLock();
		
	
		if(isLockCompatible(lock)) {

			Lock oldLock = findLock(operation.getTransactionId(), operation.getItem());
			
			
			
			if(oldLock == null) {
				insertLock(lock);
			}
			else {
				oldLock.upgradeType(lock.getType());
			}
			
		
			return true;
		}
		else {
			

			queueOperation(operation.getItem(), operation);
			
		
			return false;
		}
		
	}
	
	public void setLockTable(Hashtable<String, ArrayList<Lock>> lockTable) {
		this.lockTable = lockTable;
	}

	public void setQueueTable(Hashtable<String, ArrayList<Operation>> queueTable) {
		this.queueTable = queueTable;
	}

}
