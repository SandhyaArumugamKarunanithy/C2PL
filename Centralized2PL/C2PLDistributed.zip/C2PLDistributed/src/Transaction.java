

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Hashtable;



public class Transaction implements Serializable {
	
	
	public static final String TAG = Transaction.class.getName();
	

	private static final long serialVersionUID = 1L;

	
	public static final int ID_OFFSET = 10000;
	

	public static final int DELAY_MILLISEC = 100;
	

	public static int getSiteId(int transactionId) {
		return transactionId / Transaction.ID_OFFSET; 
	}
	
	
	public static boolean isNumber(String str) {
		return str.matches("\\d+");
	}
	

	private int id;
	

	private ArrayList<Operation> operations;

	private Hashtable<String, Integer> preCommit;
	

	private Hashtable<String, Integer> preWrite;
	

	public Transaction(int id) {
		this.id = id;
		operations = new ArrayList<Operation>();
		preCommit = new Hashtable<String, Integer>();
		preWrite = new Hashtable<String, Integer>();
	}
	
	public boolean addOperation(Operation operation) {
		operation.setTransactionId(id);
		return operations.add(operation);
	}
	

	public void commit() {
		
		/* Traverse each key element in the pre commit hash table */
		for(String key: preCommit.keySet()) {
			
			/* Get the value associated with the key */
			int value = preCommit.get(key);
			
			/* Write the pair in the database */
			DataHandler.store(key, value);
		}
	}
	
	/**
	 * Executes the given operation
	 * @param operation
	 */
	public void executeOperation(Operation operation) throws Exception {
		
		/* Try to execute the operation */
		try {
			
			/* Put the thread to sleep */
			Thread.sleep(Transaction.DELAY_MILLISEC);
			
			/* Get the data item from the operation */
			String item = operation.getItem();
			
			/* Process the operation based on its type */
			switch(operation.getType()) {
			
				/* Process a read operation */
				case Operation.TYPE_READ:
					
					/* Read the value associated to the item in the database */
					int value = DataHandler.load(item);
					
					/* Save the item and its value in the pre commit table */
					preCommit.put(item, value);
					
				break;
				
				/* Process a write operation */
				case Operation.TYPE_WRITE:
					
					/* Check previous read value from item */
					if(preWrite.containsKey(item)) {
						
						/* Save the item and its value in the pre commit table */
						preCommit.put(item, preWrite.get(item));
					}
					else {
						throw new Exception("Write operation value not available");
					}
					
				break;
				
				/* Process a math operation */
				case Operation.TYPE_MATH:
					
					/* Get the operands and the operator */
					String operand1 = operation.getOperand1();
					String operand2 = operation.getOperand2();
					String operator = operation.getOperator();
					
					/* The numeric values of the operands */
					int operand1Value;
					int operand2Value;
					
					/* The result of the operation */
					int result;
					
					/* If the first operand is a number then convert it, otherwise read
					 * from the pre commit table its correspondent value */
					if(Transaction.isNumber(operand1)) {
						operand1Value = Integer.parseInt(operand1);
					}
					else {
						operand1Value = preCommit.get(operand1);
					}
					
					/* If the second operand is a number then convert it, otherwise read
					 * from the pre commit table its correspondent value */
					if(Transaction.isNumber(operand2)) {
						operand2Value = Integer.parseInt(operand2);
					}
					else {
						operand2Value = preCommit.get(operand2);
					}
					
					/* Calculate the result based on the operator */
					switch(operator) {
					
						case "+":
							result = operand1Value + operand2Value;
						break;
						
						case "-":
							result = operand1Value - operand2Value;
						break;
						
						case "*":
							result = operand1Value * operand2Value;
						break;
						
						case "/":
							result = operand1Value / operand2Value;
						break;
						
						default:
							throw new Exception("Undefined operator");
					
					}
					
					/* Stores the item with the result */
					preWrite.put(item, result);
					
				break;
			
			}
			
		}
		catch(InterruptedException e) {
			System.out.println("Interrupted Exception: " + e.getMessage());
		}
		
		
	}
	
	/**
	 * Executes the operations in the operations list
	 * @throws Exception
	 */
	public void executeOperations() throws Exception {
		
		/* Get the size of the operations list */
		int n = operations.size();
		
		/* Execute each operation in the list */
		for(int i = 0; i < n; i += 1) {
			executeOperation(operations.get(i));
		}
		
	}
	
	/**
	 * Returns the id of the transaction
	 * @return
	 */
	public int getId() {
		return id;
	}

	/**
	 * Returns the id of the transaction in string format
	 * @return
	 */
	public String getName() {
		return "" + id;
	}

	/**
	 * Returns the list of operations in the transaction
	 * @return
	 */
	public ArrayList<Operation> getOperations() {
		return operations;
	}

	/**
	 * Returns the hash table with the pre committed atomic operations
	 * @return
	 */
	public Hashtable<String, Integer> getPreCommit() {
		return preCommit;
	}

	/**
	 * Returns the hash table with the pre written atomic operations
	 * @return
	 */
	public Hashtable<String, Integer> getPreWrite() {
		return preWrite;
	}

	/**
	 * Returns an Array List with all the write operations in the
	 * operation list
	 * @return
	 */
	public ArrayList<Operation> getWriteOperations() {
		
		/* Get the size of the operations list */
		int n = operations.size();
		
		
		if(n <= 0) {
			return null;
		}
		
		ArrayList<Operation> writeOperations = new ArrayList<Operation>();
		
		for(int i = 0; i < n; i += 1) {
		
			Operation operation = operations.get(i);
			if(operation.getType() == Operation.TYPE_WRITE) {
				writeOperations.add(operation);
			}
			
		}
		
		/* Return the write operations list */
		return writeOperations;
	}

	
	public void setId(int id) {
		this.id = id;
	}


	public void setOperations(ArrayList<Operation> operations) {
		this.operations = operations;
	}


	public void setPreCommit(Hashtable<String, Integer> preCommit) {
		this.preCommit = preCommit;
	}
	

	public void setPreWrite(Hashtable<String, Integer> preWrite) {
		this.preWrite = preWrite;
	}

	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[id: " + id);
		
		int n = operations.size();
		for(int i = 0; i < n; i += 1) {
			builder.append(", [" + operations.get(i).toString() + "]");
		}
		
		builder.append("]");
		return builder.toString();
	}

}
