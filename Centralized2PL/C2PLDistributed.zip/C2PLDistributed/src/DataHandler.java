

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DataHandler {
	
	
	public static final String TAG = DataHandler.class.getName();
	

	public static final String DB_JDBC = "org.sqlite.JDBC";
	
	
	public static final String DB_URL = "jdbc:sqlite:c2pl4.db";
	
	public static int establish() {
		
		
		Connection connection = null;
		
		
		int result = 0;
		
	
		try {
			
			
			Class.forName(DB_JDBC);
			connection = DriverManager.getConnection(DB_URL);
			
		
			Statement statement = connection.createStatement();
			statement.setQueryTimeout(30);
			
			
			statement.executeUpdate("drop table if exists items");
			
	
			String query = "create table items (item string, value integer)";
			result = statement.executeUpdate(query);
			

			statement.close();
			connection.close();
			
		}
		catch(ClassNotFoundException e) {
			System.err.println(TAG + " Class Not Found Exception: " + e.getMessage());
		}
		catch(SQLException e) {
			System.err.println(TAG + " SQL Exception: " + e.getMessage());
		}
		
	
		return result;
	}
	
	public static int load(String item) {
		

		Connection connection = null;
		
		
		int value = 0;
		

		try {
			
			
			Class.forName(DB_JDBC);
			connection = DriverManager.getConnection(DB_URL);
			Statement statement = connection.createStatement();
			statement.setQueryTimeout(30);
			String query = "select value from items where item = '" + item + "'";
			
			
			ResultSet result = statement.executeQuery(query);
			
			if(result.next()) {
				value = result.getInt("value");
			}
		
			result.close();
			statement.close();
			connection.close();
			
		}
		catch(ClassNotFoundException e) {
			System.err.println(TAG + " Class Not Found Exception: " + e.getMessage());
		}
		catch(SQLException e) {
			System.err.println(TAG + " SQL Exception: " + e.getMessage());
		}
		
	
		return value;
	}
	
	

	public static int store(String item, int value) {
		
		
		Connection connection = null;
		
		
		int result = 0;
		
		
		try {
			
		
			Class.forName(DB_JDBC);
			connection = DriverManager.getConnection(DB_URL);
			
			
			Statement statement = connection.createStatement();
			statement.setQueryTimeout(30);
			
			
			String query = "select value from items where item = '" + item + "'";
			ResultSet resultset = statement.executeQuery(query);

			if(resultset.next()) {
				query = "update items set value = " + value + " where item = '" + item + "'";
			
			}
			else {
				query = "insert into items values ('" + item + "', " + value + ")";
				
			}
			

			result = statement.executeUpdate(query);
			
			
			statement.close();
			connection.close();
			
		}
		catch(ClassNotFoundException e) {
			System.err.println(TAG + " Class Not Found Exception: " + e.getMessage());
		}
		catch(SQLException e) {
			System.err.println(TAG + " SQL Exception: " + e.getMessage());
		}
		
		
		return result;
	}

}
