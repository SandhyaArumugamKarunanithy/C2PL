

import java.rmi.Remote;
import java.rmi.RemoteException;



public interface CentralSiteInterface extends Remote {
	
	
	public int nextSiteId() throws RemoteException;
	
	public void releaseLock(Transaction transaction) throws RemoteException;

	public boolean requestLock(Operation operation) throws RemoteException;

}
