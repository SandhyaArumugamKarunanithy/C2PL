
import java.rmi.AlreadyBoundException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DataSite implements Runnable, DataSiteInterface {
	
	
	public static final String TAG = DataSite.class.getName();
	
	
	private static boolean verbose;
	
	
	public static String getTimestamp()
	{
		
		return "[" + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S").format(new Date()) + "]";
	}

	public static void main(String[] args) {
		

		verbose = (args.length > 3) ? Boolean.parseBoolean(args[3]) : true;
		println(TAG, "Creating Data Site");
		

		DataHandler.establish();
		print(TAG, "Data Handler created");
		
	
		String host = args[0];
		int port = Integer.parseInt(args[1]);
		System.out.println("Establishing Connection to Central Site at " + host + ":" + port);
		
		String transactionsFile = args[2];
		print(TAG, "Read transactions file " + transactionsFile);
		
	
		(new DataSite(host, port, transactionsFile)).run();
		
	}
	

	public static void print(String tag, String message) {
		
		if(verbose) {
			System.out.println(DataSite.getTimestamp() + " " + tag + ": " + message);
		}
	}

	public static void println(String tag, String message) {
		
	
		if(verbose) {
			System.out.println("");
			System.out.println(DataSite.getTimestamp() + " " + tag + ": " + message);
		}
	}

	private FileUtil fileUtil;
	
	
	private int id;
	
	
	private CentralSiteInterface centralSiteStub;


	private boolean blocked;


	public boolean abort;

	public DataSite(String host, int port, String transactionsFile) {
		
		blocked = false;
		abort = false;
		

		try {
			
			
			Registry registry = LocateRegistry.getRegistry(host, port);
			centralSiteStub = (CentralSiteInterface) registry.lookup("c2pl");
			
			
			id = centralSiteStub.nextSiteId();
			
	
			fileUtil = new FileUtil(id);
			fileUtil.load(transactionsFile);
			
		
			DataSiteInterface dataSiteStub = (DataSiteInterface) UnicastRemoteObject.exportObject(this, 0);
			String siteStubName = "c2pl" + id;
			registry.bind(siteStubName, dataSiteStub);
			print(TAG, "Binding Data Site as " + siteStubName);
			
			
			System.out.println(DataSite.getTimestamp() + " " + "Data site " + id + " is ready");
			
		}
		catch(RemoteException e) {
			System.out.println(TAG + " Remote Exception: " + e.getMessage());
		}
		catch(NotBoundException e) {
			System.out.println(TAG + " Not Bound Exception: " + e.getMessage());
		}
		catch(IndexOutOfBoundsException e) {
			System.out.println(TAG + " Index Out Of Bounds Exception: " + e.getMessage());
		}
		catch(AlreadyBoundException e) {
			System.out.println(TAG + " Already Bound Exception: " + e.getMessage());
		}
		catch(Exception e) {
			System.out.println(TAG + " Exception: " + e.getMessage());
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void abort() throws RemoteException {
		
		abort = true;
		print(TAG, "Current transaction is aborted!!");
		
		unblock();
		//notifyAll();
	}
	

	public synchronized void blocked() {
		
		
		try {
	
			blocked = true;
			
			
			while(blocked) {
				
			
				print(TAG, "Site " + id + " stopped. Waiting for CS...");
				
				
				Thread.sleep(1000);
			}
		}
		catch(InterruptedException e) {
			System.out.println(TAG + " Interrupted Exception: " + e.getMessage());
		}
		catch(NullPointerException e) {
			System.out.println(TAG + " Null Pointer Exception: " + e.getMessage());
		}
		catch(Exception e) {
			System.out.println(TAG + " Exception: " + e.getMessage());
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		
	
		while(true) {
			
			
			try {
				
			
				synchronized(this) {
					
					println(TAG, "Start a new transaction");
					
				
					Transaction transaction = fileUtil.popTransaction();
					print(TAG, "Transaction received");
					
				
					if(transaction == null) {
						
						print(TAG, "Transaction is null");
						
						
						print(TAG, "Site " + id + " waiting for next transaction");
		
						blocked();
						print(TAG, "Site " + id + " is now stopped");
						
					}
					else {
						
						String tag = "[T" + transaction.getId() + "]";
						print(TAG, "Starting transaction " + tag);
						
						/**/
						for(Operation operation : transaction.getOperations()) {
							
							/**/
							switch(operation.getType()) {
							
								/**/
								case Operation.TYPE_READ: {
									
									/**/
									boolean result = centralSiteStub.requestLock(operation);
									
									/**/
									if(!result) {
										blocked();
									}
									
									/**/
									if(abort) {
										break;
									}
									
									/**/
									transaction.executeOperation(operation);
									break;
								}
								
								/**/
								case Operation.TYPE_WRITE: {
									
									/**/
									boolean result = centralSiteStub.requestLock(operation);
									
									/**/
									if(!result) {
										blocked();
									}
									
									/**/
									if(abort) {
										break;
									}
									
									/**/
									transaction.executeOperation(operation);
									break;
								}
								
								/**/
								case Operation.TYPE_MATH: {
									
									/**/
									transaction.executeOperation(operation);
									break;
								}
							}
							
							/**/
							if(abort) {
								break;
							}
							
						}
						
						/**/
						if(abort) {
							
							/**/
							print(TAG, "Transaction " + transaction.getId() + " is aborted");
							
							/**/
							abort = false;
						}
						else {
							
							/**/
							transaction.commit();
							
							/**/
							centralSiteStub.releaseLock(transaction);
							
							/**/
							print(TAG, "Transaction " + transaction.getId() + " completed");
							
						}
					}
				}
			}
			catch(RemoteException e) {
				System.out.println(TAG + " Remote Exception: " + e.getMessage());
			}
			catch(Exception e) {
				System.out.println(TAG + " Exception: " + e.getMessage());
			}
		}
	}
	
	@Override
	public void unblock() throws RemoteException {
		
		println(TAG, "Preparing to resume the site");

		blocked = false;
		print(TAG, "Site is now in process");
		
		
	}

	@Override
	public void write() throws RemoteException {
		System.out.println(DataSite.getTimestamp() + " " + TAG + " Writing the info for site " + id);
	}

}
