

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class Graph<T> {
	
	 
	  public static final int VISIT_COLOR_WHITE = 1
	  public static final int VISIT_COLOR_GREY = 2;
	public static final int VISIT_COLOR_BLACK = 3;
	private List<Vertex<T>> verticies;
 private List<Edge<T>> edges;
private Vertex<T> rootVertex;
	
	  
	  public Graph() {
	    verticies = new ArrayList<Vertex<T>>();
	    edges = new ArrayList<Edge<T>>();
	  }
	
	  
	  public boolean addEdge(Vertex<T> from, Vertex<T> to, int cost) throws IllegalArgumentException {
	    if (verticies.contains(from) == false)
	      throw new IllegalArgumentException("from is not in graph");
	if (verticies.contains(to) == false)
	  throw new IllegalArgumentException("to is not in graph");
	
	    Edge<T> e = new Edge<T>(from, to, cost);
	    if (from.findEdge(to) != null)
	      return false;
	    else {
	      from.addEdge(e);
	      to.addEdge(e);
	      edges.add(e);
	      return true;
	    }
	  }
	
	  public boolean addVertex(Vertex<T> v) {
	    boolean added = false;
	    if (verticies.contains(v) == false) {
	      added = verticies.add(v);
	    }
	    return added;
	  
	  
	
	  
	
	  
	  public Edge<T>[] findCycles() {
	    ArrayList<Edge<T>> cycleEdges = new ArrayList<Edge<T>>();
	    
	for (int n = 0; n < verticies.size(); n++) {
	  Vertex<T> v = getVertex(n);
	  v.setMarkState(VISIT_COLOR_WHITE);
	}
	for (int n = 0; n < verticies.size(); n++) {
	  Vertex<T> v = getVertex(n);
	  visit(v, cycleEdges);
	}
	
	@SuppressWarnings("unchecked")
		Edge<T>[] cycles = new Edge[cycleEdges.size()];
	    cycleEdges.toArray(cycles);
	    return cycles;
	  }
	
	  
	  public Vertex<T> findVertexByData(T data, Comparator<T> compare) {
	    Vertex<T> match = null;
	    for (Vertex<T> v : verticies) {
	      if (compare.compare(data, v.getData()) == 0) {
	        match = v;
	        break;
	      }
	    }
	    return match;
	  }
	
	
	  public Vertex<T> findVertexByName(String name) {
	    Vertex<T> match = null;
	    for (Vertex<T> v : verticies) {
	      if (name.equals(v.getName())) {
	        match = v;
	        break;
	      }
	    }
	    return match;
	  }
	
	  
	  public List<Edge<T>> getEdges() {
	    return this.edges;
	  }
	
	  public Vertex<T> getRootVertex() {
	    return rootVertex;
	  }
	
	  public Vertex<T> getVertex(int n) {
	    return verticies.get(n);
	  }
	
	 
	  public List<Vertex<T>> getVerticies() {
	    return this.verticies;
	  }
	
	  
	  public boolean insertBiEdge(Vertex<T> from, Vertex<T> to, int cost)
	      throws IllegalArgumentException {
	    return addEdge(from, to, cost) && addEdge(to, from, cost);
	  }
	
	  
	  public boolean isEmpty() {
	    return verticies.size() == 0;
	  }
	
	  
	  public boolean removeEdge(Vertex<T> from, Vertex<T> to) {
	    Edge<T> e = from.findEdge(to);
	    if (e == null)
	      return false;
	    else {
	      from.remove(e);
	      to.remove(e);
	      edges.remove(e);
	      return true;
	    }
	  }

	  public boolean removeVertex(Vertex<T> v) {
	    if (!verticies.contains(v))
	      return false;
	
	    verticies.remove(v);
	    if (v == rootVertex)
	      rootVertex = null;
	
	    
	    for (int n = 0; n < v.getOutgoingEdgeCount(); n++) {
	      Edge<T> e = v.getOutgoingEdge(n);
	      v.remove(e);
	      Vertex<T> to = e.getTo();
	      to.remove(e);
	      edges.remove(e);
	    }
	    for (int n = 0; n < v.getIncomingEdgeCount(); n++) {
	      Edge<T> e = v.getIncomingEdge(n);
	      v.remove(e);
	      Vertex<T> predecessor = e.getFrom();
	      predecessor.remove(e);
	    }
	    return true;
	  }
	
	 
	  public void setRootVertex(Vertex<T> root) {
	    this.rootVertex = root;
	    if (verticies.contains(root) == false)
	      this.addVertex(root);
	  }

	  public int size() {
	    return verticies.size();
	  }
	
	  public String toString() {
	    StringBuffer tmp = new StringBuffer("Graph[");
	for (Vertex<T> v : verticies)
	  tmp.append(v);
	tmp.append(']');
	    return tmp.toString();
	  }
	
	  private void visit(Vertex<T> v, ArrayList<Edge<T>> cycleEdges) {
	    v.setMarkState(VISIT_COLOR_GREY);
	    int count = v.getOutgoingEdgeCount();
	    for (int n = 0; n < count; n++) {
	      Edge<T> e = v.getOutgoingEdge(n);
	      Vertex<T> u = e.getTo();
	      if (u.getMarkState() == VISIT_COLOR_GREY) {
	        // A cycle Edge<T>
	        cycleEdges.add(e);
	      } else if (u.getMarkState() == VISIT_COLOR_WHITE) {
	        visit(u, cycleEdges);
	      }
	    }
	    v.setMarkState(VISIT_COLOR_BLACK);
	  }

	}